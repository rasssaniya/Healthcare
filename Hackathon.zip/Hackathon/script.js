document.getElementById('otpForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting normally

    const mobileNumber = document.getElementById('mobile').value;

    // Simple validation (you can expand this)
    if (mobileNumber.length < 10) {
        document.getElementById('message').innerText = 'Please enter a valid mobile number.';
        return;
    }

    // Send mobile number to the server to generate OTP
    fetch('/generate-otp', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ mobile: mobileNumber })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            document.getElementById('message').innerText = 'OTP sent successfully!';
        } else {
            document.getElementById('message').innerText = 'Error sending OTP.';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('message').innerText = 'An error occurred.';
    });
});